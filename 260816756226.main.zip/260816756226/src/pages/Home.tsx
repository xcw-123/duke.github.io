import { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import Navbar from '@/components/Navbar';
import HeroBanner from '@/components/HeroBanner';
import ProductSection from '@/components/ProductSection';
import BrandStory from '@/components/BrandStory';
import FeaturesSection from '@/components/FeaturesSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      {/* 导航栏 - 滚动时变化样式 */}
      <Navbar scrolled={scrolled} />
      
      {/* 主视觉Banner */}
      <HeroBanner />
      
      {/* 核心产品模块 */}
      <ProductSection />
      
      {/* 品牌介绍 */}
      <BrandStory />
      
      {/* 卖点提炼 */}
      <FeaturesSection />
      
      {/* 购买引导/咨询 */}
      <ContactSection />
      
      {/* 页脚 */}
      <Footer />
    </div>
  );
}