import { motion } from "framer-motion";
import { useState } from "react";
import { toast } from "sonner";

const ContactSection = () => {
    const [name, setName] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        if (!name || !phone || !email) {
            toast.error("请填写所有必填字段");
            return;
        }

        toast.success("预约请求已提交，我们将尽快与您联系");
        setName("");
        setPhone("");
        setEmail("");
    };

    return (
        <section className="py-24 md:py-32 px-6 md:px-12 bg-gray-50">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-20 items-center">
                    {}
                    <motion.div
                        initial={{
                            opacity: 0,
                            x: -30
                        }}
                        whileInView={{
                            opacity: 1,
                            x: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8
                        }}>
                        <h2 className="text-3xl md:text-4xl font-light tracking-tight mb-6">开启您的理想空间之旅</h2>
                        <p className="text-gray-700 mb-10 max-w-md">无论您是正在寻找住宅空间的重新设计，还是商业项目的整体规划，我们都将为您提供专业的设计咨询服务，共同打造专属于您的理想空间。
                                        </p>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label htmlFor="name" className="block text-sm text-gray-600 mb-2">您的姓名</label>
                                <input
                                    type="text"
                                    id="name"
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 focus:border-gray-900 focus:outline-none transition-colors"
                                    required />
                            </div>
                            <div>
                                <label htmlFor="phone" className="block text-sm text-gray-600 mb-2">联系电话</label>
                                <input
                                    type="tel"
                                    id="phone"
                                    value={phone}
                                    onChange={e => setPhone(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 focus:border-gray-900 focus:outline-none transition-colors"
                                    required />
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm text-gray-600 mb-2">电子邮箱</label>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={e => setEmail(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 focus:border-gray-900 focus:outline-none transition-colors"
                                    required />
                            </div>
                            <motion.button
                                type="submit"
                                whileHover={{
                                    scale: 1.02
                                }}
                                whileTap={{
                                    scale: 0.98
                                }}
                                className="w-full md:w-auto px-8 py-3 bg-gray-900 text-white text-sm tracking-wide hover:bg-gray-800 transition-colors duration-300">预约免费咨询
                                              </motion.button>
                        </form>
                        <p className="text-gray-500 text-xs mt-6">我们尊重您的隐私，您的个人信息将仅用于预约沟通
                                        </p>
                    </motion.div>
                    {}
                    <motion.div
                        initial={{
                            opacity: 0,
                            x: 30
                        }}
                        whileInView={{
                            opacity: 1,
                            x: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8,
                            delay: 0.2
                        }}
                        className="relative">
                        <div className="aspect-[4/5] overflow-hidden">
                            <img
                                src="https://space-static.coze.cn/coze_space/7549384331178754313/upload/14_2625x3500.jpg?sign=1760339650-82b0b23c14-0-c01ab748bfd1deb7a852d19426d6dbf48d94be0d4c47c76430ebe914ca1562a1"
                                alt="高端室内设计"
                                className="w-full h-full object-cover" />
                        </div>
                        {}
                        <div
                            className="absolute -top-6 -right-6 w-40 h-40 border border-gray-200 z-[-1]"></div>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default ContactSection;