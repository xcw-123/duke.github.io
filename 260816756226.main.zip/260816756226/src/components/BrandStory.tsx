import { motion } from "framer-motion";

const BrandStory = () => {
    return (
        <section id="story" className="py-24 md:py-32 px-6 md:px-12 bg-white">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20 items-center">
                    {}
                    <motion.div
                        initial={{
                            opacity: 0,
                            x: -30
                        }}
                        whileInView={{
                            opacity: 1,
                            x: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8
                        }}>
                        <h2
                            className="text-3xl md:text-4xl font-light tracking-tight mb-6"
                            style={{
                                fontWeight: "bold"
                            }}>品牌故事</h2>
                        <div className="space-y-6 text-gray-700">
                            <p className="text-lg leading-relaxed">度克设计创立于2008年，由设计师周剑先生领衔，专注于高端住宅与商业空间的室内设计。我们深信，空间不仅是物理的容器，更是生活美学的载体与情感的寄托。</p>
                            <p className="leading-relaxed">十余年来，我们始终坚持"设计赋予空间价值"的设计理念，将东方哲学中的"意境"之美与现代设计语言相融合，创造出兼具文化底蕴与当代审美的理想空间。我们相信，真正的奢华不在于浮夸的装饰，而在于对材质、光影与比例的极致追求。</p>
                            <p className="leading-relaxed">每一个项目，我们都倾注心血，从空间规划到材质选择，从光影布局到细节打磨，力求在功能与美学之间找到完美平衡，为客户打造真正契合其生活方式与精神追求的理想之境。
                                              </p>
                        </div>
                        <div className="mt-10">
                            <motion.a
                                href="/about"
                                whileHover={{
                                    x: 5
                                }}
                                transition={{
                                    type: "spring",
                                    stiffness: 300
                                }}
                                className="inline-flex items-center text-sm tracking-wide font-medium">
                                <span>了解更多品牌历程</span>
                                <i class="fa-solid fa-long-arrow-right ml-2 text-xs"></i>
                            </motion.a>
                        </div>
                    </motion.div>
                    {}
                    <motion.div
                        initial={{
                            opacity: 0,
                            x: 30
                        }}
                        whileInView={{
                            opacity: 1,
                            x: 0
                        }}
                        viewport={{
                            once: true
                        }}
                        transition={{
                            duration: 0.8,
                            delay: 0.2
                        }}
                        className="relative">
                        <div className="aspect-[4/5] overflow-hidden">
                            <img
                                src="https://space-static.coze.cn/coze_space/7549384331178754313/upload/640_1080x1473.jpg?sign=1760339621-d2e6eafe94-0-d6d7125462a3c668dc83e39320f2d91abf70dc20ded679a056420fcdee47de1f"
                                alt="设计师工作场景"
                                className="w-full h-full object-cover" />
                        </div>
                        {}
                        <div
                            className="absolute -bottom-6 -left-6 w-40 h-40 border border-gray-200 z-[-1]"></div>
                    </motion.div>
                </div>
            </div>
        </section>
    );
};

export default BrandStory;