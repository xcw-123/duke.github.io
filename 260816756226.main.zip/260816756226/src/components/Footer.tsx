import { motion } from "framer-motion";

const Footer = () => {
    return (
        <footer
            className="py-16 md:py-24 px-6 md:px-12 bg-white border-t border-gray-100">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
                    {}
                    <div>
                        <h3
                            className="text-2xl font-light tracking-wider mb-6"
                            style={{
                                fontWeight: "bold"
                            }}>DUKE</h3>
                        <p className="text-gray-600 text-sm leading-relaxed mb-6">融合东方意境与现代美学，为您打造兼具温度与深度的生活空间。
                                                                                                </p>
                        <div className="flex space-x-4">
                            <a href="#" className="text-gray-500 hover:text-gray-900 transition-colors">
                                <i class="fa-brands fa-weixin text-lg"></i>
                            </a>
                            <a href="#" className="text-gray-500 hover:text-gray-900 transition-colors">
                                <i class="fa-brands fa-weibo text-lg"></i>
                            </a>
                            <a href="#" className="text-gray-500 hover:text-gray-900 transition-colors">
                                <i class="fa-brands fa-tiktok text-lg"></i>
                            </a>
                            <a href="#" className="text-gray-500 hover:text-gray-900 transition-colors">
                                <i class="fa-solid fa-book-open text-lg"></i>
                            </a>
                        </div>
                    </div>
                    {}
                    <div>
                        <h4 className="text-sm font-medium tracking-wider uppercase mb-6">快速链接</h4>
                        <ul className="space-y-4">
                            <li><a
                                    href="/"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">首页</a></li>
                            <li><a
                                    href="/projects"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">项目案例</a></li>
                            <li><a
                                    href="/services"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">设计服务</a></li>
                            <li><a
                                    href="/about"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">关于我们</a></li>
                            <li><a
                                    href="/contact"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">联系我们</a></li>
                        </ul>
                    </div>
                    {}
                    <div>
                        <h4 className="text-sm font-medium tracking-wider uppercase mb-6">服务范围</h4>
                        <ul className="space-y-4">
                            <li><a
                                    href="#"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">住宅空间设计</a></li>
                            <li><a
                                    href="#"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">商业空间设计</a></li>
                            <li><a
                                    href="#"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">软装陈设设计</a></li>
                            <li><a
                                    href="#"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">家具定制服务</a></li>
                            <li><a
                                    href="#"
                                    className="text-gray-600 text-sm hover:text-gray-900 transition-colors">全球采购服务</a></li>
                        </ul>
                    </div>
                    {}
                    <div>
                        <h4 className="text-sm font-medium tracking-wider uppercase mb-6">联系我们</h4>
                        <ul className="space-y-4 text-gray-600 text-sm">
                            <li className="flex items-start">
                                <i class="fa-solid fa-map-marker mt-1 mr-3 text-gray-400"></i>
                                <span>泰州市医药高新区悦天地西南对面卜籁咖啡隔壁<br />现代艺术中心15层</span>
                            </li>
                            <li className="flex items-center">
                                <i class="fa-solid fa-phone mr-3 text-gray-400"></i>
                                <span>+86 131 8225 9335</span>
                            </li>
                            <li className="flex items-center">
                                <i class="fa-solid fa-envelope mr-3 text-gray-400"></i>
                                <span>1260134649@qq.com</span>
                            </li>
                            <li className="flex items-center">
                                <i class="fa-solid fa-clock mr-3 text-gray-400"></i>
                                <span>周三至周一: 9:00-18:00</span>
                            </li>
                        </ul>
                    </div>
                </div>
                {}
                <div
                    className="pt-12 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center">
                    <p className="text-gray-500 text-xs mb-4 md:mb-0">© 2025 度克知舍室内设计. 保留所有权利.</p>
                    <div className="flex space-x-6">
                        <a
                            href="#"
                            className="text-gray-500 text-xs hover:text-gray-900 transition-colors">隐私政策</a>
                        <a
                            href="#"
                            className="text-gray-500 text-xs hover:text-gray-900 transition-colors">服务条款</a>
                        <a
                            href="#"
                            className="text-gray-500 text-xs hover:text-gray-900 transition-colors">网站地图</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;